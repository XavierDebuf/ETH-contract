const ganache = require('ganache');
const { Web3 } = require('web3');

// updated ganache and web3 imports added for convenience

// contract test code will go here
